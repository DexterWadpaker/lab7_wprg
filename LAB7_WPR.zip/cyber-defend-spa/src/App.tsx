// src/App.tsx
import { BrowserRouter, Routes, Route, NavLink } from 'react-router-dom';
import Home from './pages/Home';
import Projects from './pages/Projects';
import './App.css';

function App() {
  return (
    <BrowserRouter>
      <div className="app-layout">
        <header>
          <h1>ІТ-компанія "CyberDefend Solutions"</h1>
          <nav>
            {/* NavLink автоматично додає клас 'active' для активного посилання */}
            <NavLink to="/">Головна</NavLink>
            <NavLink to="/projects">Проєкти</NavLink>
          </nav>
        </header>

        <main>
          {/* Routes відповідає за підміну контенту залежно від URL */}
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/projects" element={<Projects />} />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  );
}

export default App;