export interface Project {
    id: number;
    name: string;
    status: 'В процесі' | 'Завершено' | 'Заплановано';
    year: number;
}