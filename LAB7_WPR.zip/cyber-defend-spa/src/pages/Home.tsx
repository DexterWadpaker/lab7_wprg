// src/pages/Home.tsx
export default function Home() {
    return (
        <div>
            <h2>Ласкаво просимо до CyberDefend Solutions</h2>
            <p>Ми надаємо найкращі рішення у сфері кібербезпеки.</p>
            <p>Перейдіть на вкладку "Проєкти", щоб переглянути наше портфоліо (робота з React хуками).</p>
        </div>
    );
}