// src/pages/Projects.tsx
import { useState, useEffect } from 'react';
import type { Project } from '../types/Project';

// Мокові дані для нашої ІТ-компанії
const mockProjects: Project[] = [
    { id: 1, name: 'SOC Моніторинг платформи', status: 'В процесі', year: 2025 },
    { id: 2, name: 'Аудит безпеки та Пентест', status: 'Завершено', year: 2024 },
    { id: 3, name: 'Впровадження Zero Trust', status: 'Заплановано', year: 2026 },
    { id: 4, name: 'Захист від DDoS атак', status: 'Завершено', year: 2023 },
    { id: 5, name: 'Розробка Security Dashboard', status: 'В процесі', year: 2025 },
];

export default function Projects() {
    // Стан 1: Активний фільтр статусу (за замовчуванням 'Всі')
    const [statusFilter, setStatusFilter] = useState<string>('Всі');
    
    // Стан 2: Обраний проєкт (може бути об'єктом Project або null, якщо нічого не обрано)
    const [selectedProject, setSelectedProject] = useState<Project | null>(null);

    // Сценарій useEffect згідно з Варіантом 10:
    // Скидання selectedProject (встановлення в null) при зміні statusFilter
    useEffect(() => {
        setSelectedProject(null);
        console.log(`Фільтр змінено на "${statusFilter}". Вибір проєкту скинуто.`);
    }, [statusFilter]); // Масив залежностей: ефект спрацює ТІЛЬКИ коли зміниться statusFilter

    // Обчислюємо відфільтровані проєкти
    const filteredProjects = statusFilter === 'Всі' 
        ? mockProjects 
        : mockProjects.filter(p => p.status === statusFilter);

    return (
        <div className="projects-container">
            <h2>Проєкти CyberDefend Solutions</h2>
            
            <div className="filter-controls">
                <label htmlFor="status-select">Фільтр за статусом: </label>
                <select 
                    id="status-select"
                    value={statusFilter} 
                    onChange={(e) => setStatusFilter(e.target.value)}
                >
                    <option value="Всі">Всі проєкти</option>
                    <option value="В процесі">В процесі</option>
                    <option value="Завершено">Завершено</option>
                    <option value="Заплановано">Заплановано</option>
                </select>
            </div>

            <div className="layout-grid">
                <ul className="project-list">
                    {filteredProjects.map((project) => (
                        <li 
                            key={project.id} 
                            // Встановлюємо обраний проєкт при кліку
                            onClick={() => setSelectedProject(project)}
                            className={selectedProject?.id === project.id ? 'active' : ''}
                        >
                            <strong>{project.name}</strong> — {project.status}
                        </li>
                    ))}
                    {filteredProjects.length === 0 && <li>Проєктів не знайдено.</li>}
                </ul>

                {/* Відображення деталей обраного проєкту */}
                <div className="project-details">
                    {selectedProject ? (
                        <div>
                            <h3>Деталі проєкту</h3>
                            <p><strong>ID:</strong> {selectedProject.id}</p>
                            <p><strong>Назва:</strong> {selectedProject.name}</p>
                            <p><strong>Статус:</strong> {selectedProject.status}</p>
                            <p><strong>Рік початку:</strong> {selectedProject.year}</p>
                        </div>
                    ) : (
                        <p className="placeholder">Клікніть на проєкт зі списку зліва, щоб побачити деталі.</p>
                    )}
                </div>
            </div>
        </div>
    );
}