// Оголошення дочірнього компонента (Картка проекту)
const ProjectCard = {
    // Отримання даних від батька через props
    props: {
        project: {
            type: Object,
            required: true
        }
    },
    // Шаблон компонента
    template: `
        <div class="card">
            <h4>{{ project.name }}</h4>
            <div class="card-tech">
                <span v-for="(tech, index) in project.tech" :key="index" class="tech-tag">
                    {{ tech }}
                </span>
            </div>
            <span class="card-status" :class="project.status === 'Завершено' ? 'status-done' : 'status-progress'">
                Статус: {{ project.status }}
            </span>
            <span class="card-year">Рік: {{ project.year }}</span>
            
            <button @click="$emit('show-details', project)" class="details-btn">
                Переглянути деталі
            </button>
        </div>
    `
};

// Створення екземпляру Vue додатку (Options API)
const app = Vue.createApp({
    // Реєстрація локальних компонентів
    components: {
        'project-card': ProjectCard
    },
    
    data() {
        return {
            searchQuery: '',
            currentSort: 'default',
            searchChangesCount: 0, // Змінна для спостерігача
            
            // База даних згідно з варіантом 10 (IT-компанія)
            projects: [
                { id: 1, name: 'SOC Моніторинг платформи', tech: ['Splunk', 'Suricata', 'Zeek'], status: 'В процесі', year: 2025 },
                { id: 2, name: 'Аудит безпеки та Пентест', tech: ['Burp Suite', 'Nmap', 'Metasploit'], status: 'Завершено', year: 2024 },
                { id: 3, name: 'Впровадження Zero Trust', tech: ['Cisco ISE', 'Active Directory'], status: 'Заплановано', year: 2026 },
                { id: 4, name: 'Захист від DDoS атак', tech: ['Cloudflare', 'AWS Shield'], status: 'Завершено', year: 2023 },
                { id: 5, name: 'Розробка Security Dashboard', tech: ['Vue.js 3', 'JavaScript', 'REST API'], status: 'В процесі', year: 2025 },
                { id: 6, name: 'Аналіз шкідливого ПЗ', tech: ['Ghidra', 'Cuckoo Sandbox'], status: 'Завершено', year: 2024 }
            ]
        };
    },
    
    // Спостерігач (watch) - реагує на кожну зміну searchQuery
    watch: {
        searchQuery(newValue, oldValue) {
            console.log(`Пошук змінився з "${oldValue}" на "${newValue}"`);
            this.searchChangesCount++; // Збільшуємо лічильник при кожному введенні символу
        }
    },
    
    // Обчислювані властивості (computed)
    computed: {
        filteredAndSortedProjects() {
            // КРОК 1: Фільтрація (за назвою або по масиву технологій)
            let result = this.projects.filter(project => {
                const query = this.searchQuery.toLowerCase();
                
                const matchName = project.name.toLowerCase().includes(query);
                // Перевіряємо чи є збіг у масиві технологій (tech)
                const matchTech = project.tech.some(t => t.toLowerCase().includes(query));
                
                return matchName || matchTech;
            });

            // КРОК 2: Сортування
            if (this.currentSort === 'name') {
                result.sort((a, b) => a.name.localeCompare(b.name));
            } else if (this.currentSort === 'year') {
                result.sort((a, b) => b.year - a.year); // Від найновіших
            }

            return result;
        }
    },

    // Методи (обробка подій від дочірніх компонентів)
    methods: {
        handleShowDetails(project) {
            alert(`Деталі проекту:\nID: ${project.id}\nНазва: ${project.name}\nТехнології: ${project.tech.join(', ')}\nСтатус: ${project.status}\nРік: ${project.year}`);
        }
    }
});

// Монтуємо додаток
app.mount('#portfolio-app');